Carpeta donde se contienen todos los ficheros gráficos de la aplicación
